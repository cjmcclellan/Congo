from django.apps import AppConfig


class CongoConfig(AppConfig):
    name = 'congo'
